package controlador;
// Imports 

import data.DetallesTarea;
import data.DetallesActividad;
import java.awt.PopupMenu;
import java.util.ArrayList;
import java.util.Date;
import controlador.PersonalDeCoordinacion;
//import controlador.PersonalDeProyecto;
import modelo.Actividad;
import modelo.EquipoDeTrabajo;
import modelo.Girls4Stem;
import modelo.Tarea;


public class PersonalDeCoordinacion extends PersonalDeProyecto {
    // Aquello que selecciona //
    private Tarea tareaAct;
    private Actividad actividadAct;
    private EquipoDeTrabajo equipoAct;
   

    
    // AÑADIDo a MANo EL girls4Stem QUE SE DEBE RENoMBRAR DE otra manera
    public PersonalDeCoordinacion( String nombre, Girls4Stem girls4Stem) {
        super(nombre, girls4Stem);
    }

    public Boolean modificarActividad(String nombre, String descripcion, Date fechaIni, Date fechaFin) {
        return actividadAct.modificarActividad(nombre, descripcion, fechaIni, fechaFin);
    }

    public void altaNuevaActividad(String nombre,String descripcion, Date fechaIni, Date fechaFin) {
        girls4Stem.altaNuevaActividad(nombre, descripcion, fechaIni, fechaFin);
    }

    public void duplicarActividad(String nombre, Actividad actividad) {
        girls4Stem.duplicarActividad(nombre, actividad);
    }

    public DetallesActividad consultarDetallesActividad(Object o) {
        Actividad actividad = (Actividad) o;
        actividadAct = actividad;
        return actividad.consultarDetallesAcvtividad();
    }

    public Object altaTarea(String nombre, Date fechaMaxRealizacion, Date fechaRealFinal, Object equipo, Object responsable) {
        Tarea tarea = actividadAct.altaTarea(nombre, fechaMaxRealizacion, fechaRealFinal, (EquipoDeTrabajo) equipo, (PersonalDeProyecto) responsable);
        if(tarea != null)
            tareaAct = tarea;   // se se ha creado una nueva tarea se asigna como actual
        return tarea;     
    }

    public void eliminarTarea(Object obj) {
        actividadAct.eliminarTarea((Tarea) obj);
    }

    public void modificarTarea(Date fechaMaxFin, Object equipo, Object responsable, Object tarea) {
        actividadAct.modificarTarea(fechaMaxFin, (EquipoDeTrabajo)equipo, (PersonalDeProyecto)responsable, (Tarea)tarea); 
    }

    @Override
    public ArrayList consultarTareasAsignadas() {
        // Rellenar por el usuario 
        throw new UnsupportedOperationException("Not supported yet.");
    } 
    
    public DetallesTarea consultarDetallesTarea(Object tarea) {
        tareaAct = (Tarea) tarea;
        return tareaAct.consultardetallestarea();
    }

    public ArrayList consultarEquipos() {
        return girls4Stem.consultarEquipos();
    }

    public ArrayList consultarMiembrosDelEquipo(Object equipo) {
        equipoAct = (EquipoDeTrabajo) equipo;
        return (ArrayList) equipoAct.consultarMiembros();
    }
    
    public Boolean eliminarActividad() {
        
        if(actividadAct.eliminarActividad()){
            girls4Stem.eliminarActividad(actividadAct); // eliminar del gestor del usuario
            actividadAct = null;                        // deseleccionar actividad
            return true;
        }
        else
            return false;
    }
    
    // Revisar DI0S
    public void iniciarActividad() {
        actividadAct.iniciarActividad();
    }

    
    
    
    
    
    
    
    
    

    // MÉTDOS AUXILIARES VISTA
    public Object getTareaByActividadIndex(int index) {
        return actividadAct.getTareaIndex(index);
    }

    public int getIndexResponsabelTarea(Object o) {
        Tarea tarea = (Tarea) o;
        return tarea.getIndexResponsable();
    }

    public String getNombrePersProy(Object o) {
        PersonalDeProyecto miembro = (PersonalDeProyecto) o;
        return miembro.getNombre();
    }

    public Object consultarEquipoDeTarea(Object o) {
        Tarea tarea = (Tarea) o;
        return tarea.getEquipo();
    }

    public int getIndexEquipo(Object o) {
        EquipoDeTrabajo equipo = (EquipoDeTrabajo) o;
        return girls4Stem.encuentra(equipo);
    }
    
    public ArrayList consultarActividades() {
        return girls4Stem.consultarActividades();
    }

    public String consultarEstadoActividadAct() {
        return actividadAct.consultarDetallesAcvtividad().estadoActividad;
    }

    public String consultarNombreTarea(Object o) {
        Tarea tarea = (Tarea) o;
        return tarea.consultardetallestarea().nombre;
    }

    public ArrayList consultarTareas() {
        return actividadAct.getTareas();
    }

    public String getNombreEquipo(Object o) {
        EquipoDeTrabajo equipo = (EquipoDeTrabajo) o;
        return equipo.getNombre();
    }

    public Object consultarEquipoByIndex(int index) {
        return girls4Stem.getEquipoByIndex(index);
    }

    public Object consultarMiembroByIndexEquipo(int indexMiembro, Object o) {
        EquipoDeTrabajo equipo = (EquipoDeTrabajo) o;
        return equipo.consultarMiembros().get(indexMiembro);
    }
}
