package controlador;

import java.util.ArrayList;
import java.util.Date;
import modelo.Girls4Stem;
import modelo.Tarea;
import modelo.Tarea;

 public class PersonalDeProyecto{
    private ArrayList<Tarea> tareas = new ArrayList<Tarea>();
    private  String login;
    private  String password;
    private  String nombre;
    private  String apellidos;
    private  String dni;
    private  String telefono;
    private  String correo;
    protected Girls4Stem girls4Stem;
    
    /*public PersonalDeProyecto(){}*/
    
    public PersonalDeProyecto(String nombre, Girls4Stem girls4Stem){
        this.nombre = nombre;
        this.girls4Stem = girls4Stem;
    }
    
    public ArrayList consultarTareasAsignadas() {
        //girls4Stem.consultarTareasAsignadas(); 
        //throw new UnsupportedOperationException("Not supported yet.");
        return ( new ArrayList() );
    } 

    public void anyadirTarea(Tarea tarea) {
        this.tareas.add(tarea);
    }
    
    public void eliminarTarea(Tarea tarea) {
        tareas.remove(tarea); 
    }
    
    // Cuando es mostrado como Object, muestra su nombre
    public String toString(){
        return nombre;
    }
 

    // MÉTDOS AUXILIARES PARA LA VISTA
    public String getNombre() {
        return nombre;
    }
 
}


