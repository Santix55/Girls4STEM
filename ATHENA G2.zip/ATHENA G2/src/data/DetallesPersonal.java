package data;
 // Imports 



import java.util.Date;
/** 
 clase DetallesPersonal
 */ 
public class DetallesPersonal
{
    public String login;
    public String password;
    public String nombre;
    public String apellidos;
    public String dni;
    public String telefono;
    public String correo;
 
 
    /** Metodo DetallesUsuario
    * @param String login
    * @param String password
    * @param String nombre
    * @param String apellidos
    * @param String dni
    * @param String telefono
    */ 
    public DetallesPersonal(String login, String password, String nombre, String apellidos, String dni, String telefono){
        this.login = login; 
        this.password = password; 
        this.nombre = nombre; 
        this.apellidos = apellidos; 
        this.dni = dni; 
        this.telefono = telefono; 
    } 
 }


