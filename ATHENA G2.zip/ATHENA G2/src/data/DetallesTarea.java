package data;
 // Imports 



import java.util.Date;
import java.util.ArrayList;
/** 
 clase DetallesTarea
 */ 
 public class DetallesTarea
 {
    public String nombre;
    public Date fechaMaxRealizacion;
    public Date fechaFinRealizacion;
    public Object equipo;  //cambiad0 arraiLis7 x Object
    
    // añadid0 a man0 ¿??¿ estara reflejado en el VisualParadigm ?=?¿?¿
    public Object responsable;
    public String estadoTarea;
 
 
    /** Metodo DetallesTarea
    * @param String nombre
    * @param Date fechaMaxRealizacion
    * @param String fechaRealFinal
    * @param ArrayList equipo
    */ 
    public DetallesTarea(String nombre, Date fechaMaxRealizacion, Date fechaFinRealizacion, Object equipo, Object responsable, String estadoTarea){
        this.nombre = nombre; 
        this.fechaMaxRealizacion = fechaMaxRealizacion; 
        this.fechaFinRealizacion = fechaFinRealizacion; 
        this.equipo = equipo; 
        this.responsable = responsable;
        this.estadoTarea = estadoTarea;
    } 
 }


