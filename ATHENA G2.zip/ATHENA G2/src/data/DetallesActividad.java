package data;
 // Imports 



import java.util.Date;
import java.util.ArrayList;
/** 
 clase DetallesActividad
 */ 
 public class DetallesActividad
 {
    public String nombre;
    public String descripcion;
    public Date fechaInicio;
    public Date fechaFin;
    public ArrayList tareas;
    
    public  String estadoActividad; // ¿ añadid0  a man0 ?
 
 
    /** Metodo DetallesActividad
    * @param String nombre
    * @param String descripcion
    * @param Date fechaInicio
    * @param Date fechaFin
    * @param ArrayList detallesTareas
    */ 
    public DetallesActividad(String nombre, String descripcion, Date fechaInicio, Date fechaFin, ArrayList tareas, String estadoActividad){
        this.nombre = nombre; 
        this.descripcion = descripcion; 
        this.fechaInicio = fechaInicio; 
        this.fechaFin = fechaFin; 
        this.tareas = tareas;
        this.estadoActividad = estadoActividad;
    } 
 }


