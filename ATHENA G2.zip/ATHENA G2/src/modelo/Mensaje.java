package modelo;
 // Imports 



import java.util.Date;
/** 
 clase Mensaje
 */ 
 public class Mensaje{
 
 
    private  String nombre;
    private  String contenido;
 
 
    /** Metodo Mensaje
    */ 
    public Mensaje(){
    } 
 }


