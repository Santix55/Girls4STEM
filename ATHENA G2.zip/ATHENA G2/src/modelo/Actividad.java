package modelo;

import controlador.PersonalDeProyecto;
import data.DetallesActividad;
import java.util.*;


import java.util.Date;

public class Actividad{
 
 
    private String nombre = "";
    private String descripcion = "";
    private Date fechaIni;
    private Date fechaFin;
    private ArrayList<Tarea> tareas = new ArrayList<Tarea>();
    private ArrayList<Tarea> tareasPendientes = new ArrayList<Tarea>(); // añadido a mano, se creará al regenerar el codigo
    private ArrayList<Tarea> tareasAsignadas = new ArrayList<Tarea>();
    private ArrayList<Tarea> tareasCompletadas = new ArrayList<Tarea>(); // añadido a mano, se creará al regenerar el codigo
    private EstadoActividad estadoActividad;
    private EstadoTarea estadoTarea;
 
    
    public Actividad(String nombre, Date fechaIni, Date fechaFin, String descripcion){
        this.nombre = nombre; 
        this.fechaIni = fechaIni; 
        this.fechaFin = fechaFin; 
        this.descripcion = descripcion; 
        new Planificada(this); 
    }
    
    public  Tarea altaTarea(String nombre, Date fechaMaxRealizacion, Date fechaRealFinal, EquipoDeTrabajo equipo, PersonalDeProyecto personalDeProyecto) {
        Tarea tarea = estadoActividad.altaTarea(nombre, fechaMaxRealizacion, fechaRealFinal, equipo, personalDeProyecto);
        return tarea;
    } 

    public Tarea altaTareaPlanificada(String nombre, Date fechaMaxRealizacion, Date fechaRealFinal, EquipoDeTrabajo equipo, PersonalDeProyecto personalDeProyecto) {
        Tarea tarea = new Tarea(nombre, fechaMaxRealizacion, fechaRealFinal, equipo, personalDeProyecto);
        tareas.add(tarea);
        tareasAsignadas.add(tarea);
        return tarea;
    }
 
    public  Boolean  modificarActividad(String nombre, String descripcion, Date fechaIni, Date fechaFin) {
        return estadoActividad.modificarActividad(nombre, descripcion, fechaIni, fechaFin); 
    } 
 
    public  void modificarActividadPlanificada(String nombre, String descripcion, Date fechaIni, Date fechaFin) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaIni = fechaIni;
        this.fechaFin = fechaFin;
        //this.tareas = tareas;
    } 
    
    public void modificarTarea(Date fechaMaxFin, EquipoDeTrabajo equipo, PersonalDeProyecto responsable, Tarea tarea) {
        estadoActividad.modificarTarea(fechaMaxFin, equipo, responsable, tarea); 
    } 
    
    public void modificarTareaPlanificada(Date fechaMaxFin, EquipoDeTrabajo equipo, PersonalDeProyecto responsable, Tarea tarea) {
        tarea.modificarTarea(fechaMaxFin, equipo, responsable, tarea); 
        //estadoActividad.modificarTarea(fechaMaxFin, equipo, responsable, tarea); 
        //--
    } 
 
    public DetallesActividad consultarDetallesAcvtividad() {
       DetallesActividad d = new DetallesActividad(nombre, descripcion, fechaIni, fechaFin, (ArrayList) tareas, estadoActividad.texto());
       return d;
    } 
    
    
    
    /*   ¿ALGUN PARAME7R0?  */
    
    public  void resetActividad(   ) {
        this.nombre = nombre ; 
        this.descripcion = descripcion ; 
        this.fechaIni = fechaIni ; 
        this.fechaFin = fechaFin ; 
        //Planificada planificada = new Planificada (tarea);  // cambiado Planificada por Planificada
        Planificada planificadaActividad = new Planificada(this);
    } 
 
    public  void setEstado(EstadoActividad estadoActividad) {
        this.estadoActividad = estadoActividad; 
    }
    
    public  void eliminar() {
        // oleg
        //Tarea tarea2 = new Tarea("mi_nombre", new Date(), new EquipoDeTrabajo(), new PersonalDeProyecto() );
        // se necesita la tarea x parametro o algo...
        //estadoActividad.eliminarTarea(); // this.tareas.remove(tarea2) ; 
        //tarea2.eliminarTarea(); 
        
        
       // Santi
        for(Tarea tarea: tareas)
            tarea.eliminarTarea();
        tareas.clear();
        // eliminar activdad del Girls4Stem ! NO EXISTE NAVEGABILIDAD
    } 
    
    public  void eliminarTarea(Tarea tarea) {
        estadoActividad.eliminarTarea(tarea); 
    }
    
    public void eliminarTareaPlanficada(Tarea tarea) {
        tareas.remove(tarea);
        tarea.eliminarTarea();
    }
    
    // Cuando se muestra un object se mostrará el String
    public String toString(){
        return nombre;
    }

    
    
    
    
    
    public void iniciarActividad() {
        estadoActividad.iniciarActividad();
        
        for(int i=0; i<tareas.size(); i++){   // tareas/tareasAsignadas
            Tarea tarea = tareas.get(i);
            tarea.setEstado( new EnCursoTarea( tarea ) );
        }
        
        // revisar el resto del DI0s Iniciar Actividad
    }

    public Boolean eliminarActividad() {
        return estadoActividad.eliminarActividad();
    }

    
    
    
    
    
    
    
    
    // MÉTODOS AUXILIARES PARA DEVOLVER COSAS A LA VISTA
    public Tarea getTareaIndex(int index) {
        return tareas.get(index);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaInicio() {
        return fechaIni;
    }

    public void setFechaInicio(Date fechaIni) {
        this.fechaIni = fechaIni;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public ArrayList<Tarea> getTareas() {
        return tareas;
    }

    public void setTareas(ArrayList<Tarea> tareas) {
        this.tareas = tareas;
    }

    public ArrayList<Tarea> getTareasAsignadas() {
        return tareasAsignadas;
    }

    public void setTareasAsignadas(ArrayList<Tarea> tareasAsignadas) {
        this.tareasAsignadas = tareasAsignadas;
    }

 
 
}
