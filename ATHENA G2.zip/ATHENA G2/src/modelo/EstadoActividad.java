package modelo;

import controlador.PersonalDeProyecto;
import java.util.ArrayList;
import java.util.Date;

 public class EstadoActividad{
     
    Actividad actividadAct;
     
    public EstadoActividad(Actividad actividadAct){
        this.actividadAct = actividadAct; 
        actividadAct.setEstado(this);
    }
    
    // por defecto no hace nada @Override Planficada
    public Boolean eliminarActividad() { 
        return false;
    }
    
    // por defecto no hace nada @Override Planificada pone en curso
    public void iniciarActividad() {
    }
    
    // por defecto solo devuelve que no lo modifica @Override Planificada
    Boolean modificarActividad(String nombre, String descripcion, Date fechaIni, Date fechaFin) {
        return false; 
    }

    public String texto() {
        return "Estado no especifico";
    }
    
    // no se crea ninguna Tarea por defecro @Override Planificada
    public Tarea altaTarea(String nombre, Date fechaMaxRealizacion, Date fechaRealFinal, EquipoDeTrabajo equipo, PersonalDeProyecto personalDeProyecto) {
        return null;
    }
    
    
    
    //@Override en PlanificadaActividad
    public void eliminarTarea(Tarea tarea) {
        //actividadAct.eliminar();  
    } 
    
    //@Override en PlanificadaActividad
    public void modificarTarea(Date fechaMaxFin, EquipoDeTrabajo equipo, PersonalDeProyecto responsable, Tarea tarea) {
        //actividadAct.modificar(fechaMaxFin, equipo, responsable, tarea); 
   } 
 
}


