package modelo;
 // Imports 



import java.util.Date;
/** 
 clase Asignada
 */ 
 public class Asignada  extends EstadoTarea{
 
 
 
 
    /** Metodo Asignada
    */ 
    public Asignada(Tarea tarea){
        super(tarea);
    }
    
    public String texto(){
        return "Asignada";
    }
 }


