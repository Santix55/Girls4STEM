package modelo;

import java.util.Date;

 public class EnCursoActividad  extends EstadoActividad{
 
    public EnCursoActividad(Actividad actividad){
        super(actividad);
    } 
    
    @Override
    public void iniciarActividad(){
        actividadAct.setEstado(new EnCursoActividad(actividadAct));
    }
 
    @Override
    public String texto(){
        return "En Curso";
    }
}


