package modelo;
 // Imports 



import controlador.PersonalDeProyecto;
import controlador.PersonalDeCoordinacion;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Girls4Stem{
    private ArrayList<Actividad> actividades;
    private ArrayList<EquipoDeTrabajo> equipos;
    private ArrayList<Tarea> tareas;
    private ArrayList<PersonalDeProyecto> usersProyecto;
    private PersonalDeCoordinacion coordinador;
    
    public Girls4Stem(){
        actividades = new ArrayList<Actividad>();
        equipos =  new ArrayList<EquipoDeTrabajo>();
        tareas = new ArrayList<Tarea>();
        usersProyecto = new ArrayList<PersonalDeProyecto>();
    }
    
    public void eliminarActividad(Actividad actividad) {
        actividades.remove(actividad);
    }
    
    public  void duplicarActividad(String nombre, Actividad actividad) {
        /*
        Actividad nuevaActividad = clone() : Actividad ; 
        nuevaActividad.resetActividad(); 
        */
        throw new UnsupportedOperationException("Not supported yet.");
    } 
    
    public  ArrayList<PersonalDeProyecto> consultarMiembrosDelEquipo(EquipoDeTrabajo equipo) {
        return equipo.consultarMiembros();
    }
    
    public  ArrayList<Actividad> consultarActividades() {
        return actividades ; 
    }
    
    public  ArrayList consultarEquipos() {
        return (ArrayList) equipos; 
    } 
 
    public  void consultarTareasAsignadas() {
    }
    
    public  void altaNuevaActividad(String nombre, String descripcion, Date fechaInicio, Date fechaFin) {
       actividades.add(new Actividad(nombre, fechaInicio, fechaFin, descripcion));
    } 
 
    
    
    // METÓDOS AUXILIARES
    public int encuentra(EquipoDeTrabajo equipo) {
        return equipos.indexOf(equipo);
    }

    public Object getEquipoByIndex(int index) {
        return equipos.get(index);
    }
 
    
    public PersonalDeProyecto login(){
        return coordinador;
    }
    
    // PLACEHOLDERS //
    // Eliminar cuando el XML funcione
    public void cargarDatos()
    {
        // Creación del Personal
        PersonalDeProyecto personalDeProyecto_1= new PersonalDeProyecto("Paco", this);
        PersonalDeProyecto personalDeProyecto_2 = new PersonalDeProyecto("Jaime", this);
        PersonalDeProyecto personalDeProyecto_3 = new PersonalDeProyecto("Benito", this);
        PersonalDeProyecto personalDeProyecto_4 = new PersonalDeProyecto("Andrés", this);
        coordinador = new PersonalDeCoordinacion("Miriam", this);
        
        usersProyecto.add(personalDeProyecto_1);
        usersProyecto.add(personalDeProyecto_2);
        usersProyecto.add(personalDeProyecto_3);
        usersProyecto.add(personalDeProyecto_4);
        usersProyecto.add(coordinador);
        
        
        // Creación de equipos
        ArrayList<PersonalDeProyecto> arrayEquipo2 = new ArrayList<PersonalDeProyecto>();
        arrayEquipo2.add(personalDeProyecto_1);
        arrayEquipo2.add(personalDeProyecto_2);
        arrayEquipo2.add(personalDeProyecto_3);
        
        EquipoDeTrabajo equipo1 = new EquipoDeTrabajo("Todos", usersProyecto);
        EquipoDeTrabajo equipo2 = new EquipoDeTrabajo("CasiTodos", arrayEquipo2);
        equipos.add(equipo1);
        equipos.add(equipo2);
        
        
        // Definir formato de fechas
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        
        
        
        try {
            // Creación de actividades
            Actividad actividad1 = new Actividad(
                "Terminar Modelo",
                formato.parse("05/05/2022"), formato.parse("10/12/2022"),
                "Implementa el DCD y los DIOS"
            );
            Actividad actividad2 = new Actividad(
                "Terminar Vista",
                formato.parse("06/06/2022"), formato.parse("09/12/2022"),
                "Implementa la vista usando la operaciones del DSGS"
            );
            actividades.add(actividad1);
            actividades.add(actividad2);
            
            
            // Creación de actividades (asignadas a la tarea 1)
            actividad1.altaTarea(
                    "DIOS ConsultarDetallesTarea",
                    formato.parse("06/05/2022"), formato.parse("07/05/2022"),
                    equipo1,
                    personalDeProyecto_1
            );     
            actividad1.altaTarea(
                    "DIOS ConsultarEquipos",
                    formato.parse("08/05/2022"), formato.parse("09/05/2022"),
                    equipo2,
                    personalDeProyecto_2
            );
        } catch (ParseException ex) {
            System.out.println("!Alguna fecha de activdad esta mal escrita");
            Logger.getLogger(Girls4Stem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}


