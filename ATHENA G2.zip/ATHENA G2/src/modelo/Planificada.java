/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import controlador.PersonalDeProyecto;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author santi
 */
public class Planificada extends EstadoActividad{
    
    public Planificada(Actividad actividadAct) {
        super(actividadAct);
    }
    
    @Override
    public Boolean eliminarActividad(){
        actividadAct.eliminar();
        return true;
    }
    
    @Override
    Boolean modificarActividad(String nombre, String descripcion, Date fechaIni, Date fechaFin) {
        actividadAct.modificarActividadPlanificada(nombre, descripcion, fechaIni, fechaFin);
        return true;
    }
    
    @Override
    public String texto(){
        return "Planificada";
    }
    
    @Override
    public void iniciarActividad(){
        actividadAct.setEstado(new EnCursoActividad(actividadAct));
    }
    
    @Override
    public Tarea altaTarea(String nombre, Date fechaMaxRealizacion, Date fechaRealFinal, EquipoDeTrabajo equipo, PersonalDeProyecto personalDeProyecto) {
        Tarea tarea = actividadAct.altaTareaPlanificada(nombre, fechaMaxRealizacion, fechaRealFinal, equipo, personalDeProyecto);
        return tarea;   // devuelve la tarea creada, que será la nueva actual
    }
    
    
    
    /** Metodo eliminarTarea */ 
    @Override
    public void eliminarTarea(Tarea tarea) {
        actividadAct.eliminarTareaPlanficada(tarea);  
    } 
 
    /** Metodo modificarTarea
    * @param Date fechaMaxFin
    * @param EquipoDeTrabajo equipo
    * @param PersonalDeProyecto responsable
    * @param Tarea tarea
    * @return 
    */ 
    @Override
    public void modificarTarea(Date fechaMaxFin, EquipoDeTrabajo equipo, PersonalDeProyecto responsable, Tarea tarea) {
        actividadAct.modificarTareaPlanificada(fechaMaxFin, equipo, responsable, tarea); 
   } 
    
}
