package modelo;

import java.util.Date;

 public class Completada  extends EstadoTarea{
     
    public Completada(Tarea tarea){
        super(tarea);
    }
    
    @Override
    public String texto(){
        return "Completada";
    }
 }


