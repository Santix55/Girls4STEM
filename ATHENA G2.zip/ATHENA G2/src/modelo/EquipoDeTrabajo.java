package modelo;

import controlador.PersonalDeProyecto;
import java.util.Date;
import java.util.ArrayList;

 public class EquipoDeTrabajo{
 
     private ArrayList<PersonalDeProyecto> personalDeproyectos;
     private String nombre;
     
    public EquipoDeTrabajo(String nombre, ArrayList<PersonalDeProyecto> usuarios){
        this.nombre = nombre;
        this.personalDeproyectos = usuarios;
    } 
    
    public  ArrayList<PersonalDeProyecto> consultarMiembros() {
        return this.personalDeproyectos; 
   } 
    
    // Sobreescribe el método del Object para ser mostrado en la vista
    public String toString() {
        return nombre;
    }

    // MÉTODOS AUXILIARES VISTA 
    public int encuentra(PersonalDeProyecto responsable) {
        return this.personalDeproyectos.indexOf(responsable);
    }

    public String getNombre() {
        return nombre;
    }
 
}


