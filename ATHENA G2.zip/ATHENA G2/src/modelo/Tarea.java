package modelo;

import controlador.PersonalDeProyecto;
import data.DetallesTarea;
import java.util.Date;


 public class Tarea
 {
    private String nombre;
    private Date fechaMaxRealizacion;
    private Date fechaFinalizacionReal;
    private EquipoDeTrabajo equipo;
    private PersonalDeProyecto responsable;
    private EstadoTarea estadoTarea;

    public Tarea(String nombre, Date fechaMaxRealizacion, Date fechaFinalizacionReal, EquipoDeTrabajo equipo, PersonalDeProyecto responsable){
        this.nombre = nombre;
        this.fechaMaxRealizacion = fechaMaxRealizacion;
        this.fechaFinalizacionReal = fechaFinalizacionReal;
        this.equipo = equipo;
        this.responsable = responsable;
        responsable.anyadirTarea(this);
        
        // IMPORTANTE:
        // el estado de una tarea no puede ser null, porque proboca bugs al realizar operaciones con el estado
        new Asignada(this); // en este caso es asignada porque tiene responsable
    } 
    
    public  void eliminarTarea() {
        responsable.eliminarTarea(this);   //revisar si al generar codigo, se pasa la tarea x parametro
    }
    
    /** Metodo modificarTarea
    * @param Date fechaMaxRealizacion
    * @param EquipoDeTrabajo equipo
    * @param PersonalDeProyecto respnsable
    * @param Tarea tarea
    */ 
    public  void modificarTarea(Date fechaMaxRealizacion, EquipoDeTrabajo equipo, PersonalDeProyecto responsable, Tarea tarea)
    {
        // Miriam, el equipo es para hacer bonito? oleg. 
        //PlanificadaTarea estadoTarea = (PlanificadaTarea)this.estadoTarea;  //Asignada estadoTarea = this.estadoTarea.get(i) ;
        responsable.eliminarTarea(this); //this.tareas.remove(tarea) ;   // falta hacer funcionar esTo
        
        this.fechaMaxRealizacion = fechaMaxRealizacion ; 
        this.equipo = equipo; 
        this.responsable = responsable; 
        
        responsable.anyadirTarea(this);
    }
    
    public  DetallesTarea consultardetallestarea() {
        if(estadoTarea == null)
            System.out.println("Bug tarea null");
       return new DetallesTarea(this.nombre, this.fechaMaxRealizacion, this.fechaFinalizacionReal, this.equipo, this.responsable, this.estadoTarea.texto());
    } 

    public void setEstado(EstadoTarea estadoTarea) {
        this.estadoTarea = estadoTarea;
    }
    
    // Este método no hace falta que aparezca en ningún DIOS, ya que
    // sobreescribe el tipo Object.
    // Devuelve el string que representa a la Tarea
    public String toString(){
        return nombre;
    }

    
    
    
    
    
    // MÉTODOS AUXILIARES PARA LA VISTA
    public int getIndexResponsable() {
        return equipo.encuentra(responsable);
    }
    
    public EquipoDeTrabajo getEquipo() {
        return equipo;
    }
    
}


