package modelo;

import java.util.Date;

 public class EstadoTarea{
     Tarea tarea;
     
    public EstadoTarea(Tarea tarea){
        this.tarea = tarea;
        tarea.setEstado(this);
    } 

    String texto() {
        return "Estado no especificado";
    }
 }


